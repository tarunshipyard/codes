<?php
//session 
session_start();
$msg="";
include('config.php');
include('fun.php');
if( !(isset($_SESSION['userwaliID']))){
	header('Location: index.php');
}
if(isset($_POST['uplbtn'])){
	$name=$_FILES['pic']['name'];
	$type=$_FILES['pic']['type'];
	$tmp_name=$_FILES['pic']['tmp_name'];
	$error=$_FILES['pic']['error'];
	$size=$_FILES['pic']['size'];
	$ext=explode('.',$name);
	$ext=strtolower(end($ext)); 
	$allowedExt=array('pdf','PDF');
	$name=$class=$tcno=$tclink=$dt="";
	/* pdf details */
	$name = test_input($_POST['name']);
	$class = $_POST['class'];
	$tcno = test_input($_POST['tcno']);
	$tclink="img/".time().".".$ext;
	if(in_array($ext, $allowedExt)){
		if($error<1){
			if(($size/1024)<2000){
				if(move_uploaded_file($tmp_name,$tclink)){
					$sql = "INSERT INTO dtc1.data (`name`, `class`, `tcno`, `tclink`) VALUES ('$name', '$class', '$tcno', '$tclink')";
					if(mysqli_query($conn,$sql)){
						$msg=1;
						}
				}else{
					echo "error occured";
				}
			}else{
				echo "file size should be less than 300KB";
			}
		}
		else{
			echo "server error";
		}
	  }
	else{
		//echo "File  type is invalid or File Not Selected";
		$msg="0";	
	}
}
$sqli="Select * from dtc1.data ORDER by `dt` DESC";
$resi=mysqli_query($conn,$sqli);
//print_r($rowi);
if(isset($_POST['log'])){
session_destroy();
header('Location: index.php');
}
?>
<!-- <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script> -->
<!DOCTYPE html>
<html>
<head>
	<title>TC Upload SECTION</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<div class="container" style="    border-radius: 10px 10px 10px 10px;
    -moz-border-radius: 10px 10px 10px 10px;
    -webkit-border-radius: 10px 10px 10px 10px;
    border: 0px solid #000000;
    padding: 15px;
    border: 1px solid blue;">
<form action="home.php" method="post" enctype="multipart/form-data">
	<div class="form-group">
    <label for="exampleFormControlFile1">Upload TC (Only pdf format accepted) </label>
    <label style="float: right;" for="exampleFormControlFile1"><a href="downloadtc.php" type="submit" class="btn btn-warning">Download TC</a>&nbsp;<button type="submit" class="btn btn-primary" onclick="" name="log">Logout</button></label>
    <input type="file" class="form-control-file" id="pic" name="pic" accept="pdf">
  	</div>
  	<?php if($msg==1){ ?>
  		<div class="alert alert-success">
		  <strong>Oops!</strong> TC Uploaded Successfully ! 
		</div>
  	<?php } ?>
  	<?php if($msg=="0"){ ?>
  	<div class="input-group mb-0">
		<div class="alert alert-danger">
		  <strong>Oops!</strong> Name/Sr.no or Class is Incorrect. Only Upload Pdf
		</div>
	</div>
		<?php } ?>
  	<div class="form-group">
    <label for="exampleInputEmail1">Student Name</label>
    <input type="text" class="form-control" id="" name="name" placeholder="Enter Student Name" >
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Student Class</label>
    <select name="class" class="form-control" >
    	<option value="" >Enter Student Class</option>
    	<option value="1">1</option>
    	<option value="2">2</option>
    	<option value="3">3</option>
    	<option value="4">4</option>
    	<option value="5">5</option>
    	<option value="6">6</option>
    	<option value="7">7</option>
    	<option value="8">8</option>
    	<option value="9">9</option>
    	<option value="10">10</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Student TC Serial No.</label>
    <input type="text" class="form-control" id="" name="tcno" placeholder="Enter TC Serial No." >
  </div>
  <button type="submit" class="btn btn-success" name="uplbtn">Submit</button>
</form>
</div>
<div class="container">
	<h3>TC Recently Uploaded</h3>
  <!-- <div class="alert alert-success" id="rds" style="display: none;">
      <strong>Oops!</strong> Record Deleted Successfully ! 
  </div> -->
	<table class="table table-bordered">
    <thead>
      <tr>
      	<th>Select</th>
        <th>Name</th>
        <th>Class</th>
        <th>Date Uploaded</th>
        <th>TC No.</th>
      </tr>
    </thead>
    <tbody>
    	<?php while($rowi=mysqli_fetch_assoc($resi)) {  ?>
      <tr>
      	<td>
      		<a href="delete.php?pid=<?php echo $rowi['srn']; ?>" name="rmp">
				<span class="glyphicon glyphicon-remove">Delete </span>
			</a>
      	</td>
       <td><?php echo $rowi['name']; ?></td>
       <td><?php echo $rowi['class']; ?></td>
       <td><?php echo $rowi['dt']; ?></td>
       <td><?php echo $rowi['tcno']; ?></td>
      </tr>
  <?php    } ?>
    </tbody>
  </table>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
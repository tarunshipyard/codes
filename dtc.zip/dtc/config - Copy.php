<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
    //die("Connection failed: " . mysqli_connect_error());
    echo "string";
}
$sqli="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'dtc1'";  //Check if database exists
$rowi=mysqli_query($conn, $sqli); //run query
$rowcount=mysqli_num_rows($rowi); //$rowcount gives u gives you exist as 1 
   //echo "<pre>";
  //print_r($rowcount);
if($rowcount==0){
		$sql = "CREATE DATABASE  IF NOT EXISTS dtc1";
		mysqli_query($conn, $sql);
		$sqli="CREATE TABLE dtc1.user ( srn INT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(30) NOT NULL, pass VARCHAR(30) NOT NULL, leml VARCHAR(50), lpwd VARCHAR(50) ,reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP )";
		mysqli_query($conn, $sqli); 
		$sqli="CREATE TABLE dtc1.data ( srn INT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(30) NOT NULL, class VARCHAR(30) NOT NULL, tcno VARCHAR(50), tclink VARCHAR(50) ,dt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP )";
		mysqli_query($conn, $sqli); 

		
	} 
	else { 
		echo "dd";
	 }
?>
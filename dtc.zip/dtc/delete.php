<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

</body>
</html>
<?php 
session_start();
$msg="";
include('config1.php');
include('fun.php');
//include('fun.php');
if( !(isset($_SESSION['userwaliID']))){
	header('Location: index.php');
}
$rowi=$_SESSION['userwaliID'];
	$bi=$_GET['pid'];
	$sqlio="select tclink from dtc1.data where srn='$bi' ";
	$result = $conn->query($sqlio);
	if ($result->num_rows ==1) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "id: " . $row["tclink"];
        $path=$row["tclink"];
	    unlink($path);
	    if(!unlink($path)){
	    	echo "You have an error !";
	    	header('Location: home.php');
	    }
	    else {
	    	echo "You have an deleted your file";
	    	header('Location: home.php');
	    }
    }
} else {
    echo "0 results";

}
	$sqlio = "delete from dtc1.data where srn='$bi' ";
	mysqli_query($conn, $sqlio);
	header('Location: home.php');
?>